@php
    /**
    * Adnan Bashir
    * E: developer.adnan@gmail.com
    * P: +92-332-3103324
    * S: developer.adnan
    */
    $form_buttons = ['save', 'view', 'delete', 'back'];
@endphp
@extends('admin.layouts.admin')

@section('content')
    <style>
        .multi-ul{
            padding: 0;
            list-style: none;
        }
        .multi-ul li {
            width: 30%;
            float: left;
        }
    </style>
    <form action="{{ admin_url('store', true) }}" method="post" enctype="multipart/form-data" id="tasks">
        @csrf
        @include('admin.layouts.inc.stickybar', compact('form_buttons'))
        <input type="hidden" name="id" class="form-control" placeholder="{{ __('ID') }}" value="{{ old('id', $row->id) }}">
        <!-- begin:: Content -->


        <div class="row">
            <div class="col-lg-12">

                <div class="kt-portlet" data-ktportlet="true" id="kt_portlet_tools_1">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <div class="kt-portlet__head-label">
                            <span class="kt-portlet__head-icon">
                                @if(!empty($_info->image))
                                    <img src="{{ _img(asset_url('media/icons/' . $_info->image, true), 28, 28) }}" alt="{{ $_info->title }}">
                                @else
                                    <i class="{{ (!empty($_info->icon) ? $_info->icon : 'flaticon-list-2') }}"></i>
                                @endif
                            </span>
                                <h3 class="kt-portlet__head-title"> {{ $_info->title }} Form </h3>
                            </div>
                        </div>
                        @include('admin.layouts.inc.portlet')
                    </div>

                    <div class="kt-portlet__body">

                        <div class="form-group row">
                            <div class="col-lg-4">
                                <label for="task" class="-col-2 col-form-label required">{{ __('Task Type') }}:</label>
                                <select name="assign_data[task_type]" id="task_type" class="form-control m-select2">
                                    <option value="">Select Project</option>
                                    <?php
                                    $row->assign_data = json_decode($row->assign_data);
                                    $task_types = ['Database Update', 'Registration', 'Screening', 'Profile completion'];
                                    echo selectBox(array_combine($task_types, $task_types), old('assign_data.task_type', $row->assign_data->task_type));?>
                                </select>
                            </div>
                            <div class="col-lg-8">
                                <label for="task" class="-col-2 col-form-label required">{{ __('Task') }}:</label>
                                <input type="text" name="task" id="task" class="form-control" placeholder="{{ __('Task') }}" value="{{ old('task', $row->task) }}"/>
                            </div>
                        </div>
                        <div class="kt-separator kt-separator--border-dashed kt-separator--space-md"></div>

                        <div class="form-group row">
                            <div class="col-lg-12 range-checkboxes">
                                <label for="task" class="-col-2 col-form-label required">{{ __('AMS Members') }}:</label>

                                <div class="kt-portlet__body">
                                    @php
                                        $associations = App\Association::all();
                                    @endphp
                                    <ul class="nav nav-tabs nav-fill" role="tablist">
                                        @foreach($associations as $k => $association)
                                            <li class="nav-item">
                                                <a class="nav-link {{ $k==0 ? 'active' : '' }}" data-toggle="tab" href="#kt_tabs_{{ ($k + 1) }}">{{ $association->name }}</a>
                                            </li>
                                        @endforeach
                                    </ul>

                                    <div class="tab-content">
                                        @foreach($associations as $k => $association)
                                            <div class="tab-pane {{ $k==0 ? 'active' : '' }}" id="kt_tabs_{{ ($k + 1) }}" role="tabpanel">
                                                @php

                                                    $SQL = DB::table('members')->selectRaw("members.id
                                                    , members.name
                                                    , members.company
                                                    -- , members.city
                                                    , members.data->>'$.license' AS license
                                                    , members.data->>'$.screening' AS screening
                                                    , members.data->>'$.profile' AS profile
                                                    ")
                                                    ->where('members.association_id', $association->id)->orderBy('members.name', 'ASC');
                                                    $paginate_OBJ = $SQL->paginate(99999999);
                                                    $query = str_replace('?', $association->id, $SQL->toSql());

                                                    $grid = new Grid();
                                                    //$grid->status_column_data = $status_column_data;
                                                    $grid->sorting = false;
                                                    $grid->filterable = false;
                                                    $grid->show_paging_bar = false;
                                                    $grid->search_box = false;
                                                    $grid->actionColumn = false;
                                                    $grid->init($paginate_OBJ, $query);
                                                    $grid->dt_column(['ids' => ['wrap' => function($value, $field, $_row, $grid) use($row) {
                                                        return '<label class="kt-checkbox kt-checkbox--solid m-checkbox--brand"><input type="checkbox" name="assign_data[member_id][]" value="'.$_row['id'].'" '.(in_array($_row['id'], $row->assign_data->member_id) ? 'checked' : '').' class="chk-id"><span></span></label>';
                                                    }]]);
                                                    $grid->dt_column(['id' => ['hide' => true]]);

                                                    echo $grid->showGrid();


                                                    /*$_M = new Multilevel();
                                                    $_M->type = 'checkbox';
                                                    $_M->id_Column = 'id';
                                                    $_M->title_Column = 'company';
                                                    $_M->link_Column = 'company';
                                                    $_M->selected = $row->assign_data->member_id;
                                                    $_M->attrs = "name='member_ids[]' class=''";
                                                    $_M->call_func = function ($item, $li_html, $selected) use ($row, $association){

                                                        $html = '<li class="multi_checkbox checkbox_li_'.$item['id'].'">
                                                                    <label class="kt-checkbox kt-checkbox--bold kt-checkbox--brand">
                                                                        <input name="assign_data[member_id][]" '.(in_array($item['id'], $row->assign_data->member_id) ? 'checked' : '').' type="checkbox" value="'.$item['id'].'"> '.$item['company'] . ' - ' . $association->name.'
                                                                        <span></span>
                                                                    </label>
                                                                </li>';
                                                        return $html;
                                                    };

                                                    $_M->selected = old('member_ids', $row->member_ids);
                                                    $_M->query = $query;*/
                                                    //echo $_M->build();
                                                @endphp
                                            </div>
                                        @endforeach
                                    </div>
                                </div>



                            </div>
                        </div>
                        <div class="kt-separator kt-separator--border-dashed kt-separator--space-md"></div>


                        <div class="form-group row">
                            <div class="col-lg-2 offset-1">
                                <label for="start_date" class="-col-2 col-form-label required">{{ __('Start Date') }}:</label>
                                <input type="text" name="start_date" id="start_date" class="form-control datepicker" placeholder="{{ __('Start Date') }}" autocomplete="off" value="{{ old('start_date', $row->start_date) }}"/>
                            </div>
                            <div class="col-lg-2">
                                <label for="end_date" class="-col-2 col-form-label required">{{ __('End Date') }}:</label>
                                <input type="text" name="end_date" id="end_date" class="form-control datepicker" placeholder="{{ __('End Date') }}" autocomplete="off" value="{{ old('end_date', $row->end_date) }}"/>
                            </div>
                            <div class="col-lg-2">
                                <label for="estimate_time" class="-col-2 col-form-label required">{{ __('Estimate Time') }}:</label>
                                <div class="input-group">
                                    <input type="text" name="estimate_time" id="estimate_time" class="form-control" placeholder="{{ __('Estimate Time') }}" value="{{ old('estimate_time', $row->estimate_time) }}"/>
                                    <div class="input-group-append"><span class="input-group-text">Hour's</span></div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label for="assign_to" class="-col-2 col-form-label required">{{ __('Assign To') }}:</label>
                                <select name="assign_to" id="assign_to" class="form-control m-select2">
                                    <option value="">Select Assign To</option>
                                    {!! selectBox("SELECT id, CONCAT_WS(' ', first_name, last_name) AS assign_to FROM users WHERE user_type_id='".get_option('agent_type_id')."'", old('assign_to', $row->assign_to)) !!}
                                </select>
                            </div>
                        </div>
                        <div class="kt-separator kt-separator--border-dashed kt-separator--space-md"></div>
                        <div class="form-group row">
                            <div class="col-12">
                                <label for="description" class="col-form-label text-center">{{ __('Description') }}:</label>
                                <textarea name="description" id="description" placeholder="{{ __('Description') }}" class="editor form-control" cols="30" rows="5">{{ old('description', $row->description) }}</textarea>
                            </div>
                        </div>
                        <div class="kt-separator kt-separator--border-dashed kt-separator--space-md"></div>

                    </div>

                    <div class="kt-portlet__foot">
                        <div class="btn-group">
                            @php
                                $Form_btn = new Form_btn();
                                echo $Form_btn->buttons($form_buttons);
                            @endphp
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </form>
    <!--end::Form-->
@endsection

{{-- Scripts --}}
@section('scripts')
    <script>

        $("form#tasks").validate({
            // define validation rules
            rules: {
                'assign_data[task_type]': {
                    required: true,
                },
                'task': {
                    required: true,
                },
                'start_date': {
                    required: true,
                },
                'end_date': {
                    required: true,
                },
                'estimate_time': {
                    required: true,
                },
                'assign_to': {
                    required: true,
                },
            },
            /*messages: {
            'task' : {required: 'Task is required',},'start_date' : {required: 'Start Date is required',},'end_date' : {required: 'End Date is required',},'estimate_time' : {required: 'Estimate Time is required',},'assign_to' : {required: 'Assign To is required',},    },*/
            //display error alert on form submit
            invalidHandler: function (event, validator) {
                KTUtil.scrollTop();
                //validator.errorList[0].element.focus();
            },
            submitHandler: function (form) {
                form.submit();
            }

        });
    </script>@endsection
