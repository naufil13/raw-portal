INSERT INTO modules (`module`, `title`, `parent_id`, `icon`, `image`, `ordering`, `show_on_menu`, `actions`, `status`, `created_at`, `updated_at`) VALUES ('tasks', 'Task', '0', '', 'coding.png', '13', '1', 'add|edit|delete|status|import|export', 'Active', '2019-11-06 11:52:57', '2019-11-08 13:14:24');

#
# TABLE STRUCTURE FOR: tasks
#

CREATE TABLE `tasks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `task` varchar(255) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `estimate_time` int(9) DEFAULT NULL,
  `status` enum('Initiate','Pending','Pause','Hold','Completed') NOT NULL DEFAULT 'Initiate',
  `creator_id` bigint(11) DEFAULT NULL,
  `assign_to` bigint(11) DEFAULT NULL,
  `description` text,
  `priority` enum('High','Medium','Low') NOT NULL DEFAULT 'Medium',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `assign_data` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
