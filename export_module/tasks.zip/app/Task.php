<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    //protected $perPage = 15;

    protected $guarded = [];


    public function projects()
    {
        return $this->hasOne('App\project', 'id', 'project_id');
    }

    public function users()
    {
        return $this->hasOne('App\user', 'id', 'assign_to');
    }

    public function creator()
    {
        return $this->hasOne('App\user', 'id', 'creator_id');
    }
}
