INSERT INTO modules (`module`, `title`, `parent_id`, `icon`, `image`, `ordering`, `show_on_menu`, `actions`, `status`, `created_at`, `updated_at`) VALUES ('members', 'Customers', '0', '', 'skills.png', '11', '1', 'add|edit|delete|status|view', 'Active', '2019-11-08 15:24:54', '2021-05-18 13:05:44');

#
# TABLE STRUCTURE FOR: members
#

CREATE TABLE `members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `association_id` bigint(20) DEFAULT NULL,
  `company` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `joining_date` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emails` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phones` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
